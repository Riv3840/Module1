<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>ik heb geen idee
    </title>
    <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>

    <form method="post" action="create.php">
        <input type="text" placeholder="Naam" name="naam"><br>
        <input type="text" placeholder="country" name="country"><br>
        <input type="date" name="datum"><br>
        <input type="submit" name="submit" value="Verzenden"><br>
    </form><br>

    <?php include 'read.php'; ?>
</body>
</html>