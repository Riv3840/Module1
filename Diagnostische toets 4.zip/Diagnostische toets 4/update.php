<?php
include 'connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
}

$select = $conn->query("SELECT * FROM artist WHERE id=$id");
$row = $select->fetch_assoc(); // Use fetch_assoc() instead of fetch()

if (isset($_POST['submit'])) {

    $naam = $_POST['name']; // Correct variable name
    $taakomschrijving = $_POST['taakomschrijving'];

    $query = "UPDATE artist SET name = ?, country = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    
    // Bind parameters
    $stmt->bind_param("ssi", $naam, $taakomschrijving, $id);

    $stmt->execute();

    header("location: index.php");
}
?>

<form method="post">
    <input type="text" name="name" value="<?php echo $row['name'] ?>" onblur="checkInput('name')"><br>
    <input type="text" name="country" value="<?php echo $row['country']; ?>" onblur="checkInput('country')"><br>
    <input type="date" name="datum" value="<?php echo $row['datum']; ?>" onblur="checkInput('datum')"><br>
    <input type="submit" name="submit" value="Updaten"><br>
</form>
<script>
    function checkInput(id) {
        console.log("We zitten nu in de checkinput");
        let element = document.getElementsByName(id)[0];

        if (element.value.length < 3) {
            element.style.backgroundColor = "red";
        } else {
            element.style.backgroundColor = "lightgreen";
        }
    }
    console.log("We zitten nu in de checkinput");
</script>
